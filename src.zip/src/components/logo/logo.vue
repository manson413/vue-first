<template>
<div>
  <a href="index.html">
    <div class="header-logo">
      <div class="logo-img">
        <img src="../../assets/img/logo.jpg" alt="">
      </div>
      <div class="logo-name">Inventory</div>
    </div>
  </a>
</div>
</template>
<style lang="scss">
  @import "logo";
</style>
