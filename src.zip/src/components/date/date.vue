<template>
<div>
  <div class="week-day">{{showDay()}}</div>
</div>
</template>
<script>

  export default {
    name: 'app',
    data () {
      return {
//        msg: 'Welcome to Your Vue.js App'
      }
    },
    methods: {

    },
    computed: {
      showDay(){
        let date = new Date();
        let days = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];
        return days[date.getDay()];
      },
      showDate(){
        let date = new Date();
        return date.toLocaleString("en-US", options);
      }
    },
    components: {

    }
  }
</script>

<style lang="scss">
  @import "date";
</style>
