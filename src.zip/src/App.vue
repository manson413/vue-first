

<template>
  <div id="app">
      <app-header></app-header>

</div>
</template>

<script>
  import Header from './components/header/header.vue';
let comp = {
  template:'<div>Hello World</div>'
};
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods: {

  },
  computed: {

  },
  components: {
      AppHeader: Header
  }
}
</script>

<style lang="scss">
@import "common";
</style>
